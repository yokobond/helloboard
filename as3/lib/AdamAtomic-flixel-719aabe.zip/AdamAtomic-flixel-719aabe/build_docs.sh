#! /bin/sh
/Applications/Adobe\ Flex\ Builder\ 3\ Plug-in/sdks/3.1.0/bin/asdoc -source-path . -doc-sources . -output docs